# WA Private Group Link Scanner — Android

## What this app does
- Option 1: Android Notification Listener captures invite URLs that appear in WhatsApp or WhatsApp Business notification previews.
- Option 2: Android Share target accepts text shared from WhatsApp into this app and extracts invite URLs.
- Both are selectable and can be used together. Links are deduplicated and stored locally on the device.
- Copy/export captured links.

## Critical limitations
This does **not** read WhatsApp's private database, enumerate all groups, or retrieve a group's own invite link. Notification access only sees content Android exposes in notifications; WhatsApp may hide message previews, and muted/disabled notifications won't be captured. Share mode only scans text explicitly shared to the app. No root is used.

## Build APK without a computer (GitHub Actions)
This package is source code, not a compiled APK. To produce an installable APK using only your Android phone:
1. In Chrome, create/sign in to a GitHub account.
2. Create a new repository (choose Public or Private).
3. Upload the contents of this ZIP into the repository. Make sure `.github/workflows/build-apk.yml` is included.
4. Open the repository's **Actions** tab. Select **Build Android APK** and tap **Run workflow** (or push the files to `main`).
5. Wait for the workflow to finish. Open the completed run and download the artifact named `WA-Group-Link-Scanner-debug-apk`.
6. Extract the downloaded artifact ZIP; tap `app-debug.apk` and allow Chrome/Files to install unknown apps if Android asks.

A debug APK is suitable for personal testing. It is not Play Store signed/release-ready. Android may show an unknown developer warning because it is self-built.

## First launch
1. Open the app.
2. Turn on Option 1 if desired, then tap **Enable notification access** and enable WA Private Group Link Scanner.
3. Leave Option 2 enabled to receive text shared from WhatsApp.
4. In WhatsApp, use Share on a message/text containing a group invite link and choose this app.
5. Review captured links, then copy or export.

## Privacy
No internet permission is declared. Notification text and extracted links are stored in app-private SharedPreferences on the phone. Enabling notification access is a sensitive Android permission; only enable it if comfortable with this app reading notification content.
