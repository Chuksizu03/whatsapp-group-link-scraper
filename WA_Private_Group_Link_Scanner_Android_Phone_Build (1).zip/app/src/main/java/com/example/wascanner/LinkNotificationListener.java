package com.example.wascanner;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.app.Notification;
import android.os.Bundle;

public class LinkNotificationListener extends NotificationListenerService {
    @Override public void onNotificationPosted(StatusBarNotification sbn){
        if(sbn==null || sbn.getPackageName()==null || !sbn.getPackageName().equals("com.whatsapp")
                && !sbn.getPackageName().equals("com.whatsapp.w4b")) return;
        Notification n=sbn.getNotification();
        if(n==null || n.extras==null)return;
        Bundle b=n.extras;
        CharSequence title=b.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text=b.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if(text==null)text=b.getCharSequence(Notification.EXTRA_TEXT);
        CharSequence lines=b.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)==null?null:
                join(b.getCharSequenceArray(Notification.EXTRA_TEXT_LINES));
        String body=(text==null?"":text.toString())+(lines==null?"":" "+lines);
        String group=title==null?"WhatsApp notification":title.toString();
        Store.scan(this,body,group,"Notification");
    }
    private CharSequence join(CharSequence[] a){
        StringBuilder s=new StringBuilder(); for(CharSequence x:a)if(x!=null)s.append(x).append(' ');
        return s;
    }
}
