package com.example.wascanner;

import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.provider.Settings;
import android.net.Uri;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

public class MainActivity extends Activity {
    TextView status, list;
    CheckBox notifyMode, shareMode;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(28,28,28,20);
        root.setBackgroundColor(0xFFF4F7F6);
        TextView title=new TextView(this); title.setText("WA Private Group Link Scanner");
        title.setTextSize(22); title.setTextColor(0xFF075E54); title.setTypeface(null,1); root.addView(title);
        TextView intro=new TextView(this); intro.setText("Choose how to collect invite links. Both modes can be enabled together.");
        intro.setPadding(0,12,0,12); root.addView(intro);

        notifyMode=new CheckBox(this); notifyMode.setText("Option 1: Scan WhatsApp notifications"); notifyMode.setChecked(true); root.addView(notifyMode);
        TextView note1=new TextView(this); note1.setText("Captures invite links only when WhatsApp includes them in notification previews. Requires notification access.");
        note1.setTextSize(12); root.addView(note1);
        Button grant=new Button(this); grant.setText("Enable notification access"); grant.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))); root.addView(grant);

        shareMode=new CheckBox(this); shareMode.setText("Option 2: Scan text shared to this app"); shareMode.setChecked(true); root.addView(shareMode);
        TextView note2=new TextView(this); note2.setText("In WhatsApp, select/copy a message or use Share → WA Private Group Link Scanner. Links in the shared text are extracted.");
        note2.setTextSize(12); note2.setPadding(0,0,0,8); root.addView(note2);

        Button refresh=new Button(this); refresh.setText("Refresh captured links"); refresh.setOnClickListener(v->render()); root.addView(refresh);
        Button copy=new Button(this); copy.setText("Copy all unique links"); copy.setOnClickListener(v->copy()); root.addView(copy);
        Button export=new Button(this); export.setText("Share / export links"); export.setOnClickListener(v->share()); root.addView(export);
        Button clear=new Button(this); clear.setText("Clear saved links"); clear.setOnClickListener(v->{Store.clear(this);render();}); root.addView(clear);
        status=new TextView(this); status.setTextSize(16); status.setTypeface(null,1); status.setPadding(0,12,0,8); root.addView(status);
        ScrollView sc=new ScrollView(this); list=new TextView(this); list.setTextIsSelectable(true); sc.addView(list);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        TextView foot=new TextView(this);
        foot.setText("Privacy & limits: data stays on this phone. Android notification access can read notification content, so enable it only if you trust this app. Notifications may omit message text, and muted chats or disabled previews may not be scanned. This app cannot open WhatsApp's private database or enumerate all group members/groups.");
        foot.setTextSize(11); foot.setTextColor(0xFF705B20); foot.setPadding(0,10,0,0); root.addView(foot);
        setContentView(root);
        handleShare(getIntent());
        render();
    }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);handleShare(i);render();}
    private void handleShare(Intent i){
        if(i==null || !Intent.ACTION_SEND.equals(i.getAction()) || !shareModeEnabled())return;
        CharSequence cs=i.getCharSequenceExtra(Intent.EXTRA_TEXT);
        if(cs==null && i.getClipData()!=null && i.getClipData().getItemCount()>0)cs=i.getClipData().getItemAt(0).coerceToText(this);
        if(cs!=null){int n=Store.scan(this,cs.toString(),"Shared WhatsApp text","Share");Toast.makeText(this,"Added "+n+" new link(s)",Toast.LENGTH_LONG).show();}
    }
    private boolean shareModeEnabled(){return getPreferences(0).getBoolean("share",true);}
    private void render(){
        JSONArray a=Store.get(this); status.setText(a.length()+" unique invite links saved");
        StringBuilder s=new StringBuilder();
        for(int i=0;i<a.length();i++)try{JSONObject o=a.getJSONObject(i);
            s.append(i+1).append(". ").append(o.optString("group")).append(" (").append(o.optString("source")).append(")\n")
             .append(o.optString("url")).append("\n\n");
        }catch(Exception ignored){}
        list.setText(s.length()==0?"No links captured yet.":s.toString());
        getPreferences(0).edit().putBoolean("share",shareMode.isChecked()).apply();
    }
    private String all(){
        JSONArray a=Store.get(this);StringBuilder s=new StringBuilder();
        for(int i=0;i<a.length();i++)try{s.append(a.getJSONObject(i).optString("url")).append('\n');}catch(Exception ignored){}
        return s.toString().trim();
    }
    private void copy(){
        String s=all(); if(s.isEmpty()){Toast.makeText(this,"No links yet",0).show();return;}
        ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("WhatsApp links",s));
        Toast.makeText(this,"Copied links",0).show();
    }
    private void share(){
        String s=all();if(s.isEmpty()){Toast.makeText(this,"No links yet",0).show();return;}
        Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"WhatsApp group invite links");i.putExtra(Intent.EXTRA_TEXT,s);
        startActivity(Intent.createChooser(i,"Export links"));
    }
}
