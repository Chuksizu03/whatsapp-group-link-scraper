package com.example.wascanner;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Iterator;
import java.util.regex.*;

public class Store {
    private static final String PREF="captured_links";
    private static final Pattern URL=Pattern.compile("https?://chat\\.whatsapp\\.com/[A-Za-z0-9_-]+",Pattern.CASE_INSENSITIVE);
    public static synchronized int scan(Context c,String text,String group,String source){
        if(text==null)return 0;
        SharedPreferences p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        String raw=p.getString("items","[]");
        JSONArray arr;
        try{arr=new JSONArray(raw);}catch(Exception e){arr=new JSONArray();}
        java.util.HashSet<String> seen=new java.util.HashSet<>();
        for(int i=0;i<arr.length();i++)try{seen.add(arr.getJSONObject(i).optString("url"));}catch(Exception ignored){}
        Matcher m=URL.matcher(text); int added=0;
        while(m.find()){
            String url=m.group().replaceAll("[),.;\\\\]]+$","");
            if(seen.add(url)){
                JSONObject o=new JSONObject();
                try{o.put("url",url);o.put("group",group==null||group.isEmpty()?"Unknown group":group);
                    o.put("source",source);o.put("time",System.currentTimeMillis());arr.put(o);added++;}
                catch(Exception ignored){}
            }
        }
        p.edit().putString("items",arr.toString()).apply();
        return added;
    }
    public static synchronized JSONArray get(Context c){
        try{return new JSONArray(c.getSharedPreferences(PREF,0).getString("items","[]"));}
        catch(Exception e){return new JSONArray();}
    }
    public static synchronized void clear(Context c){c.getSharedPreferences(PREF,0).edit().putString("items","[]").apply();}
}
